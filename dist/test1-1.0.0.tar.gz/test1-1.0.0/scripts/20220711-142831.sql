create table tmp_table (id integer)
